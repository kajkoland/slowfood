class Direction < ApplicationRecord
	belongs_to :recipe
end
