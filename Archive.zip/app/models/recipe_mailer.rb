class RecipeMailer < ActionMailer::Base

  add_template_helper(RecipesHelper)

  default from: "apoch632@gmail.com"

  def recipe_send(recipe)
    @recipe = recipe
    mail(to: "allen.patrick.king@gmail.com", subject: "Your subject")
  end
end