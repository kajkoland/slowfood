class Ingredient < ApplicationRecord
  belongs_to :recipe
end
